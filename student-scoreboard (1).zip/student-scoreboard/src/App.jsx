import { useState } from 'react'
import Header from './components/Header'
import StudentTable from './components/StudentTable'
import AddStudentForm from './components/AddStudentForm'
import './App.css'

const initialStudents = [
  { id: 1, name: 'Aarav Sharma',   score: 85 },
  { id: 2, name: 'Priya Mehta',    score: 37 },
  { id: 3, name: 'Rohan Verma',    score: 62 },
  { id: 4, name: 'Ananya Singh',   score: 28 },
  { id: 5, name: 'Karan Patel',    score: 74 },
]

function App() {
  const [students, setStudents] = useState(initialStudents)

  // Update score for a specific student
  const updateScore = (id, newScore) => {
    setStudents(prev =>
      prev.map(s => s.id === id ? { ...s, score: Number(newScore) } : s)
    )
  }

  // Add a new student
  const addStudent = (name, score) => {
    const newStudent = {
      id: Date.now(),
      name,
      score: Number(score),
    }
    setStudents(prev => [...prev, newStudent])
  }

  // Stats
  const passCount = students.filter(s => s.score >= 40).length
  const failCount = students.length - passCount
  const avg = students.length
    ? (students.reduce((a, s) => a + s.score, 0) / students.length).toFixed(1)
    : 0

  return (
    <div className="app">
      <Header />

      <div className="stats-bar">
        <div className="stat">
          <span className="stat-value">{students.length}</span>
          <span className="stat-label">Total Students</span>
        </div>
        <div className="stat">
          <span className="stat-value pass-color">{passCount}</span>
          <span className="stat-label">Passed</span>
        </div>
        <div className="stat">
          <span className="stat-value fail-color">{failCount}</span>
          <span className="stat-label">Failed</span>
        </div>
        <div className="stat">
          <span className="stat-value accent-color">{avg}</span>
          <span className="stat-label">Avg Score</span>
        </div>
      </div>

      <StudentTable students={students} updateScore={updateScore} />
      <AddStudentForm addStudent={addStudent} />
    </div>
  )
}

export default App
