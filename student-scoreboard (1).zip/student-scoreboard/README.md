# 🏆 Student Scoreboard

A React application built with Vite that displays and manages student scores.

## Features

- 📋 View all students and their scores in a table
- ✏️ Update student scores dynamically
- ➕ Add new students via a form
- ✅ Pass/Fail status based on marks (Pass ≥ 40, Fail < 40)
- 📊 Live stats: total students, pass count, fail count, average score

## Tech Stack

- **React 18** (functional components + hooks)
- **Vite** (build tool)
- **Pure CSS** (no Tailwind or any UI library)

## Component Structure

```
src/
├── App.jsx              → Root component, holds all state
├── App.css
├── index.css            → Global styles
├── main.jsx             → Entry point
└── components/
    ├── Header.jsx       → App title & subtitle
    ├── Header.css
    ├── StudentTable.jsx → Renders the table
    ├── StudentTable.css
    ├── StudentRow.jsx   → Individual student row (reusable)
    ├── StudentRow.css
    ├── AddStudentForm.jsx → Form to add new students
    └── AddStudentForm.css
```

## Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Assignment

Web Development II — Assignment 3  
Unit 3: Component-based architecture with React
